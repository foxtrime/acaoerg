<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>A&ccedil;&atilde;o Ergon&ocirc;mica - Banco de Dados</title>
<style type="text/css">
<!--
body{
	padding:0px;
	text-align:center;
	margin-top: 10%;
	margin-right: 0px;
	margin-bottom: 0px;
	margin-left: 0px;
}
#formulario {
	background-color: #FFB66C;
}
-->
</style>
</head>

<body>
<form name="login" method="post" action="autentica.php">
<table cellpadding="5" cellspacing="0" border="0" id="formulario">
  <tr>
      <td>A&ccedil;&atilde;o Ergonomica</td>
      <td rowspan="3"><input type="image" src="imagens/logo.jpg" /></td>
  </tr>
  <tr>
    <td>
		<label for="login">Login</label>
		<input type="text" name="login" />
	</td>
    </tr>
  <tr>
    <td>
		<label for="senha">Senha</label>
		<input type="password" name="senha" />	
	</td>
  </tr>
</table>
</form>
</body>
</html>
